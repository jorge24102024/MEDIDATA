const express = require('express');
const app = express();
const port = 8080; 
const db = require('./db'); 

app.use(express.static('public'));
app.use(express.json());


function generarCodigoAleatorio() {
    return Math.random().toString(36).substring(2, 10).toUpperCase();
}


app.get('/api/productos', (req, res) => {
    const query = 'SELECT * FROM productos'; 
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).send('Error en la base de datos');
        } else {
            res.json(results); 
        }
    });
});


app.post('/api/productos', (req, res) => {
    const { nombreProducto, cantidad, precio } = req.body;
    const total = cantidad * precio;
    const codigoProducto = generarCodigoAleatorio(); 

    
    const query = 'INSERT INTO productos (nombreProducto, cantidad, precio, total, codigoProducto, fecha) VALUES (?, ?, ?, ?, ?, NOW())';

    db.query(query, [nombreProducto, cantidad, precio, total, codigoProducto], (err, result) => {
        if (err) {
            res.status(500).send('Error al agregar el producto');
        } else {
 
            res.json({
                id: result.insertId,
                nombreProducto,
                cantidad,
                precio,
                total,
                codigoProducto, 
                fecha: new Date().toISOString().split('T')[0]
            });
        }
    });
});


app.post('/api/login', (req, res) => {
    const { usuario, contrasena } = req.body;


    console.log('Datos recibidos para login:', { usuario, contrasena });


    const query = 'SELECT * FROM usuarios WHERE usuario = ? AND contrasena = ?';

    db.query(query, [usuario, contrasena], (err, results) => {
        if (err) {
            console.error('Error en la base de datos:', err); 
            return res.status(500).send('Error en la base de datos');
        }

        console.log('Resultados de la consulta:', results); 
       
        if (results.length > 0) {
          
            res.json({ success: true });
        } else {
          
            res.json({ success: false });
        }
    });
});


app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});
