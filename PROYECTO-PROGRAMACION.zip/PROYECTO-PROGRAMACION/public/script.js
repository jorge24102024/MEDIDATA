
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); 

    const usuario = document.getElementById('usuario').value;
    const contrasena = document.getElementById('contrasena').value;

  
    fetch('http://localhost:8080/api/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ usuario, contrasena })
    })
    .then(response => response.json())
    .then(data => {
      
        if (data.success) {
          
            document.getElementById('login-section').style.display = 'none'; 
            document.getElementById('inventario-section').style.display = 'block'; 
            cargarProductos();
        } else {
          
            document.getElementById('login-error').style.display = 'block';
        }
    })
    .catch(error => console.error('Error al autenticar al usuario:', error));
});


function cargarProductos() {
    fetch('http://localhost:8080/api/productos')
        .then(response => response.json())
        .then(data => {
            const tabla = document.getElementById('inventario').getElementsByTagName('tbody')[0];
            tabla.innerHTML = ''; 

            data.forEach(producto => {
                const nuevaFila = tabla.insertRow();
                nuevaFila.insertCell(0).textContent = producto.id;
                nuevaFila.insertCell(1).textContent = producto.nombreProducto;
                nuevaFila.insertCell(2).textContent = producto.cantidad;
                nuevaFila.insertCell(3).textContent = producto.precio.toFixed(2); 
                nuevaFila.insertCell(4).textContent = (producto.cantidad * producto.precio).toFixed(2); 
                nuevaFila.insertCell(5).textContent = producto.fecha ? new Date(producto.fecha).toLocaleString() : 'Fecha no disponible'; // Fecha de Registro
                nuevaFila.insertCell(6).textContent = producto.codigoProducto; 
            });
        })
        .catch(error => console.error('Error al cargar productos:', error));
}


document.getElementById('producto-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const nombreProducto = document.getElementById('nombreProducto').value;
    const cantidad = parseInt(document.getElementById('cantidad').value);
    const precio = parseFloat(document.getElementById('precio').value);

   
    fetch('http://localhost:8080/api/productos', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ nombreProducto, cantidad, precio })
    })
    .then(response => response.json())
    .then(data => {
        
        cargarProductos();
        this.reset(); 
    })
    .catch(error => console.error('Error al agregar producto:', error));
});
