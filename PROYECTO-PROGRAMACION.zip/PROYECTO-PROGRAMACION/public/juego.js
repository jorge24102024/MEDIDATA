const preguntas = [
    { pregunta: "1. ¿Cuál es el puerto por defecto en el servidor de Express?",
         opciones: ["3000", "8080", "8000"], 
         respuesta: "8080" },
    { pregunta: "2. ¿Qué comando se utiliza para servir archivos estáticos en Express?", 
        opciones: ["app.serve", "app.use", "app.static"], 
        respuesta: "app.use" },
    { pregunta: "3. ¿En qué archivo se define la conexión a la base de datos en Node.js?", 
        opciones: ["db.js", "app.js", "index.js"], 
        respuesta: "db.js" },
    { pregunta: "4. ¿Qué extensión tiene un archivo de estilo en CSS?", 
        opciones: [".css", ".html", ".js"], 
        respuesta: ".css" },
    { pregunta: "5. ¿Cuál es la etiqueta HTML utilizada para enlazar un archivo CSS?",
         opciones: ["<link>", "<style>", "<css>"], 
         respuesta: "<link>" },
    { pregunta: "6. ¿Cómo se declara una función en JavaScript?",
         opciones: ["function nombreFunción()", "function = nombreFunción()", "función()"],
          respuesta: "function nombreFunción()" },
    { pregunta: "7. ¿Qué propiedad CSS se utiliza para cambiar el color de fondo?", 
        opciones: ["color", "background-color", "bgcolor"], 
        respuesta: "background-color" },
    { pregunta: "8. ¿Cuál es el propósito del middleware 'express.json()' en Express?", 
        opciones: ["Manejar datos de formulario", "Manejar JSON en solicitudes", "Manejar archivos estáticos"], respuesta: "Manejar JSON en solicitudes" },
    { pregunta: "9. ¿Qué método se usa para hacer una consulta SQL en MySQL desde Node.js?", 
        opciones: ["db.run", "db.execute", "db.query"],
         respuesta: "db.query" },
    { pregunta: "10. ¿Cuál es el archivo principal de una página HTML?",
         opciones: ["index.html", "home.html", "main.html"],
          respuesta: "index.html" },
    { pregunta: "11. ¿Qué etiqueta se usa para crear un formulario en HTML?",
         opciones: ["<form>", "<input>", "<button>"], 
         respuesta: "<form>" },
    { pregunta: "12. ¿Qué comando se usa en Node.js para iniciar el servidor en Express?",
         opciones: ["app.listen()", "app.run()", "app.start()"],
          respuesta: "app.listen()" },
    { pregunta: "13. ¿Cuál es el atributo de un input para definir texto obligatorio?", 
        opciones: ["placeholder", "required", "mandatory"], 
        respuesta: "required" },
    { pregunta: "14. ¿Qué propiedad CSS alinea el texto al centro?",
         opciones: ["text-align: left;", "text-align: center;", "align: center"],
          respuesta: "text-align: center;" },
    { pregunta: "15. ¿Cuál es la etiqueta para incluir un script en HTML?", 
        opciones: ["<style>", "<script>", "<code>"], 
        respuesta: "<script>" },
    { pregunta: "16. ¿Cómo se declara una constante en JavaScript?",
         opciones: ["let constante =", "var constante =", "const constante ="],
          respuesta: "const constante =" },
    { pregunta: "17. ¿Qué propiedad CSS cambia el color del texto?",
         opciones: ["background", "font-color", "color"],
          respuesta: "color" },
    { pregunta: "18. ¿Qué función se usa en MySQL para seleccionar todos los datos de una tabla?",
         opciones: ["GET", "SELECT *", "SELECT"], 
         respuesta: "SELECT *" },
    { pregunta: "19. ¿Qué significa HTTP en las rutas de Express?",
         opciones: ["Hyper Text Transfer Protocol", "Hyper Transfer Text Protocol", "Hyperlink Transfer Protocol"],
          respuesta: "Hyper Text Transfer Protocol" },
    { pregunta: "20. ¿Cómo se define el ancho de una imagen en HTML?",
         opciones: ["width", "alt", "size"], 
         respuesta: "width" }
];

let indicePregunta = 0;
let puntaje = 0;

const preguntaElement = document.getElementById("pregunta");
const opcionesElement = document.getElementById("opciones");
const siguienteButton = document.getElementById("siguiente");
const resultadoElement = document.getElementById("resultado");
const reiniciarButton = document.getElementById("reiniciar");


reiniciarButton.style.display = "none";

function cargarPregunta() {
    const preguntaActual = preguntas[indicePregunta];
    preguntaElement.textContent = preguntaActual.pregunta;
    opcionesElement.innerHTML = ""; 
    preguntaActual.opciones.forEach(opcion => {
        const button = document.createElement("button");
        button.textContent = opcion;
        button.onclick = () => validarRespuesta(opcion);
        opcionesElement.appendChild(button);
    });
    siguienteButton.style.display = "none"; 
    resultadoElement.textContent = ""; 
}

function validarRespuesta(opcionSeleccionada) {
    const preguntaActual = preguntas[indicePregunta];
    if (opcionSeleccionada === preguntaActual.respuesta) {
        resultadoElement.textContent = "¡Correcto!";
        puntaje++;
    } else {
        resultadoElement.textContent = `Incorrecto. La respuesta correcta era: ${preguntaActual.respuesta}`;
    }
    siguienteButton.style.display = "block"; 
}

function siguientePregunta() {
    indicePregunta++;
    if (indicePregunta < preguntas.length) {
        cargarPregunta();
    } else {
        mostrarResultadoFinal();
    }
}

function mostrarResultadoFinal() {
    preguntaElement.style.display = "none";
    opcionesElement.style.display = "none";
    resultadoElement.innerHTML = `Juego terminado. Tu puntaje es: ${puntaje} de ${preguntas.length}`;
    siguienteButton.style.display = "none";
    reiniciarButton.style.display = "block"; 
}

function reiniciarJuego() {
    indicePregunta = 0;
    puntaje = 0;
    preguntaElement.style.display = "block";
    opcionesElement.style.display = "block";
    reiniciarButton.style.display = "none"; 
    cargarPregunta();
}

siguienteButton.onclick = siguientePregunta;
reiniciarButton.onclick = reiniciarJuego;

cargarPregunta(); 
